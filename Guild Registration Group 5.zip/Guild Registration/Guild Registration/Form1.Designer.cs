﻿namespace Guild_Registration
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtbCharName = new TextBox();
            txtLvl = new TextBox();
            cbClass = new ComboBox();
            cbPosition = new ComboBox();
            listView1 = new ListView();
            btnregistration = new Button();
            btnRemove = new Button();
            pictureBox1 = new PictureBox();
            btnRecord = new Button();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Bisque;
            label1.Font = new Font("Gloucester MT Extra Condensed", 18F);
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Image = Properties.Resources.textbox;
            label1.Location = new Point(60, 48);
            label1.Name = "label1";
            label1.Size = new Size(124, 28);
            label1.TabIndex = 0;
            label1.Text = "Character Name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Bisque;
            label2.Font = new Font("Gloucester MT Extra Condensed", 18F);
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Image = Properties.Resources.textbox;
            label2.Location = new Point(60, 169);
            label2.Name = "label2";
            label2.Size = new Size(137, 28);
            label2.TabIndex = 1;
            label2.Text = "What is your level:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Bisque;
            label3.Font = new Font("Gloucester MT Extra Condensed", 18F);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Image = Properties.Resources.textbox;
            label3.Location = new Point(290, 48);
            label3.Name = "label3";
            label3.Size = new Size(97, 28);
            label3.TabIndex = 2;
            label3.Text = "Select Class:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Bisque;
            label4.Font = new Font("Gloucester MT Extra Condensed", 18F);
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Image = Properties.Resources.textbox;
            label4.Location = new Point(290, 169);
            label4.Name = "label4";
            label4.Size = new Size(116, 28);
            label4.TabIndex = 3;
            label4.Text = "Select Position:";
            // 
            // txtbCharName
            // 
            txtbCharName.BackColor = Color.LightSalmon;
            txtbCharName.Location = new Point(60, 85);
            txtbCharName.Margin = new Padding(0);
            txtbCharName.Multiline = true;
            txtbCharName.Name = "txtbCharName";
            txtbCharName.Size = new Size(124, 23);
            txtbCharName.TabIndex = 4;
            // 
            // txtLvl
            // 
            txtLvl.BackColor = Color.LightSalmon;
            txtLvl.Location = new Point(56, 219);
            txtLvl.Margin = new Padding(0);
            txtLvl.Multiline = true;
            txtLvl.Name = "txtLvl";
            txtLvl.Size = new Size(141, 23);
            txtLvl.TabIndex = 5;
            // 
            // cbClass
            // 
            cbClass.BackColor = Color.LightSalmon;
            cbClass.FormattingEnabled = true;
            cbClass.Location = new Point(290, 85);
            cbClass.Margin = new Padding(0);
            cbClass.Name = "cbClass";
            cbClass.Size = new Size(121, 23);
            cbClass.TabIndex = 6;
            // 
            // cbPosition
            // 
            cbPosition.BackColor = Color.LightSalmon;
            cbPosition.FormattingEnabled = true;
            cbPosition.Location = new Point(290, 219);
            cbPosition.Margin = new Padding(0);
            cbPosition.Name = "cbPosition";
            cbPosition.Size = new Size(121, 23);
            cbPosition.TabIndex = 7;
            // 
            // listView1
            // 
            listView1.BackColor = Color.FromArgb(128, 64, 0);
            listView1.BackgroundImage = Properties.Resources.background;
            listView1.BorderStyle = BorderStyle.FixedSingle;
            listView1.ForeColor = SystemColors.WindowText;
            listView1.Location = new Point(60, 260);
            listView1.Name = "listView1";
            listView1.Size = new Size(346, 155);
            listView1.TabIndex = 8;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // btnregistration
            // 
            btnregistration.BackColor = Color.SandyBrown;
            btnregistration.BackgroundImage = Properties.Resources.textbox;
            btnregistration.Font = new Font("Gloucester MT Extra Condensed", 18F);
            btnregistration.Location = new Point(515, 48);
            btnregistration.Name = "btnregistration";
            btnregistration.Size = new Size(123, 42);
            btnregistration.TabIndex = 9;
            btnregistration.Text = "Register";
            btnregistration.UseVisualStyleBackColor = false;
            // 
            // btnRemove
            // 
            btnRemove.BackColor = Color.SandyBrown;
            btnRemove.BackgroundImage = Properties.Resources.textbox;
            btnRemove.Font = new Font("Gloucester MT Extra Condensed", 18F);
            btnRemove.Location = new Point(515, 119);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(123, 42);
            btnRemove.TabIndex = 10;
            btnRemove.Text = "Remove";
            btnRemove.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Screenshot_2024_12_07_1357201;
            pictureBox1.Location = new Point(-3, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(792, 446);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            pictureBox1.MouseDown += Form1_MouseDown;
            pictureBox1.MouseMove += Form1_MouseMove;
            pictureBox1.MouseUp += Form1_MouseUp;
            // 
            // btnRecord
            // 
            btnRecord.BackColor = Color.SandyBrown;
            btnRecord.BackgroundImage = Properties.Resources.textbox;
            btnRecord.Font = new Font("Gloucester MT Extra Condensed", 18F);
            btnRecord.Location = new Point(515, 190);
            btnRecord.Name = "btnRecord";
            btnRecord.Size = new Size(123, 42);
            btnRecord.TabIndex = 12;
            btnRecord.Text = "Record ";
            btnRecord.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.gw2eb95q;
            pictureBox2.Location = new Point(722, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(41, 33);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 13;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // Form1
            // 
            AutoScaleMode = AutoScaleMode.Inherit;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(775, 439);
            Controls.Add(txtbCharName);
            Controls.Add(listView1);
            Controls.Add(cbPosition);
            Controls.Add(cbClass);
            Controls.Add(txtLvl);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnRecord);
            Controls.Add(btnRemove);
            Controls.Add(btnregistration);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Guild Registration";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtbCharName;
        private TextBox txtLvl;
        private ComboBox cbClass;
        private ComboBox cbPosition;
        private ListView listView1;
        private Button btnregistration;
        private Button btnRemove;
        private PictureBox pictureBox1;
        private Button btnRecord;
        private PictureBox pictureBox2;
    }
}
