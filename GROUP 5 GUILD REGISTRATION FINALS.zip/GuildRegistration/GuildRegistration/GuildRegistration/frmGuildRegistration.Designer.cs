﻿namespace GuildRegistration
{
    partial class frmGuildRegistration
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGuildRegistration));
            label1 = new Label();
            label5 = new Label();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            listViewRecord = new ListView();
            btnRegister = new Button();
            cbPosition = new ComboBox();
            cbClass = new ComboBox();
            txtLvl = new TextBox();
            txtCharName = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel1 = new Panel();
            panel2 = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ControlLight;
            label1.Font = new Font("Impact", 20F, FontStyle.Italic);
            label1.Image = Properties.Resources._14;
            label1.Location = new Point(62, 203);
            label1.Name = "label1";
            label1.Size = new Size(201, 34);
            label1.TabIndex = 0;
            label1.Text = "Character Name:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.Window;
            label5.Font = new Font("Impact", 20.25F, FontStyle.Italic);
            label5.Location = new Point(3, 316);
            label5.Name = "label5";
            label5.Size = new Size(155, 34);
            label5.TabIndex = 12;
            label5.Text = "Member List:";
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Name";
            columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Class";
            columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Position";
            columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Level";
            columnHeader4.Width = 100;
            // 
            // listViewRecord
            // 
            listViewRecord.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4 });
            listViewRecord.Font = new Font("Impact", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            listViewRecord.FullRowSelect = true;
            listViewRecord.GridLines = true;
            listViewRecord.Location = new Point(0, 363);
            listViewRecord.Name = "listViewRecord";
            listViewRecord.Size = new Size(617, 215);
            listViewRecord.TabIndex = 11;
            listViewRecord.UseCompatibleStateImageBehavior = false;
            listViewRecord.View = View.Details;
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.Black;
            btnRegister.BackgroundImage = Properties.Resources.Screenshot_2024_12_09_1215541;
            btnRegister.FlatStyle = FlatStyle.Popup;
            btnRegister.Font = new Font("Impact", 20.25F, FontStyle.Italic);
            btnRegister.ForeColor = Color.White;
            btnRegister.Location = new Point(696, 483);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(131, 56);
            btnRegister.TabIndex = 8;
            btnRegister.Text = "Register";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += btnRegister_Click;
            // 
            // cbPosition
            // 
            cbPosition.FormattingEnabled = true;
            cbPosition.Location = new Point(321, 372);
            cbPosition.Name = "cbPosition";
            cbPosition.Size = new Size(141, 23);
            cbPosition.TabIndex = 7;
            // 
            // cbClass
            // 
            cbClass.FormattingEnabled = true;
            cbClass.Location = new Point(321, 247);
            cbClass.Name = "cbClass";
            cbClass.Size = new Size(141, 23);
            cbClass.TabIndex = 6;
            // 
            // txtLvl
            // 
            txtLvl.Location = new Point(62, 372);
            txtLvl.Multiline = true;
            txtLvl.Name = "txtLvl";
            txtLvl.Size = new Size(148, 23);
            txtLvl.TabIndex = 5;
            // 
            // txtCharName
            // 
            txtCharName.Location = new Point(65, 247);
            txtCharName.Multiline = true;
            txtCharName.Name = "txtCharName";
            txtCharName.Size = new Size(145, 27);
            txtCharName.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ControlLight;
            label4.Font = new Font("Impact", 20.25F, FontStyle.Italic);
            label4.Image = Properties.Resources._15;
            label4.Location = new Point(62, 328);
            label4.Name = "label4";
            label4.Size = new Size(196, 34);
            label4.TabIndex = 3;
            label4.Text = "What your Level:";
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Plum;
            label3.Font = new Font("Impact", 20.25F, FontStyle.Italic);
            label3.ForeColor = Color.Black;
            label3.Image = Properties.Resources._15;
            label3.Location = new Point(321, 328);
            label3.Name = "label3";
            label3.Size = new Size(186, 34);
            label3.TabIndex = 2;
            label3.Text = "Select Position:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.LightCyan;
            label2.Font = new Font("Impact", 20.25F, FontStyle.Italic);
            label2.ForeColor = Color.Black;
            label2.Image = Properties.Resources._15;
            label2.Location = new Point(321, 203);
            label2.Name = "label2";
            label2.Size = new Size(157, 34);
            label2.TabIndex = 1;
            label2.Text = "Select Class:";
            // 
            // panel1
            // 
            panel1.BackgroundImage = Properties.Resources._99;
            panel1.BackgroundImageLayout = ImageLayout.Stretch;
            panel1.Controls.Add(listViewRecord);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(3, -6);
            panel1.Name = "panel1";
            panel1.Size = new Size(814, 529);
            panel1.TabIndex = 13;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.BackgroundImage = (Image)resources.GetObject("panel2.BackgroundImage");
            panel2.BackgroundImageLayout = ImageLayout.Stretch;
            panel2.Controls.Add(btnRegister);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(txtLvl);
            panel2.Controls.Add(cbPosition);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(txtCharName);
            panel2.Controls.Add(cbClass);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(-53, -120);
            panel2.Name = "panel2";
            panel2.Size = new Size(995, 649);
            panel2.TabIndex = 13;
            panel2.Paint += panel2_Paint;
            // 
            // frmGuildRegistration
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(810, 516);
            Controls.Add(panel1);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "frmGuildRegistration";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmGuildRegistration";
            Load += frmGuildRegistration_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Label label5;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ListView listViewRecord;
        private Button btnRegister;
        private ComboBox cbPosition;
        private ComboBox cbClass;
        private TextBox txtLvl;
        private TextBox txtCharName;
        private Label label4;
        private Label label3;
        private Label label2;
        private Panel panel1;
        private Panel panel2;
    }
}
