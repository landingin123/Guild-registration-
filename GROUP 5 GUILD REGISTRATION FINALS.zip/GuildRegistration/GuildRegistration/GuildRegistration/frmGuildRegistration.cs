using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GuildRegistration
{
    public partial class frmGuildRegistration : Form
    {
        public frmGuildRegistration()
        {
            InitializeComponent();
        }

        private string ConnectionString = "Data Source=WIN-05142TEMACP\\SQLEXPRESS03;Initial Catalog=Guild;Integrated Security=True;Encrypt=False";
        private void btnRegister_Click(object sender, EventArgs e)
        {

            string charName = txtCharName.Text.Trim();
            string classType = cbClass.Text;
            string position = cbPosition.Text;
            if (!int.TryParse(txtLvl.Text, out int lvl))
            {
                MessageBox.Show("Please enter a valid numeric level.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection sc = new SqlConnection(ConnectionString))
            {
                sc.Open();

                string query = "INSERT INTO GuildBar (Name, Class, Position, Level) VALUES (@name, @class, @position, @level)";
                using (SqlCommand cm = new SqlCommand(query, sc))
                {
                    cm.Parameters.AddWithValue("@name", charName);
                    cm.Parameters.AddWithValue("@class", classType);
                    cm.Parameters.AddWithValue("@position", position);
                    cm.Parameters.AddWithValue("@level", lvl);

                    cm.ExecuteNonQuery();
                }
            }

            // Add to the ListView
            ListViewItem item = new ListViewItem(charName);
            item.SubItems.Add(classType);
            item.SubItems.Add(position);
            item.SubItems.Add(lvl.ToString());

            listViewRecord.Items.Add(item);

        }


        private void frmGuildRegistration_Load(object sender, EventArgs e)
        {
            var skills = new[] { "One Hand Sword", "Bow", "Katana", "Two Hand Sword", "Bowgun", "Knuckles" };
            cbClass.Items.AddRange(skills);

            var positions = new[] { "Tank", "Mage", "Support Healer", "Damage Dealers (DPS)", "Buffer", "Melee DPS" };
            cbPosition.Items.AddRange(positions);
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
