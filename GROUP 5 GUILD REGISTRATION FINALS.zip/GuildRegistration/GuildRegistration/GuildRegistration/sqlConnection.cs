﻿namespace GuildRegistration
{
    internal class sqlConnection
    {
    }
}