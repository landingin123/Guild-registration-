﻿namespace Guild_Registration
{
    partial class frmGuildRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new ListView();
            pictureBox2 = new PictureBox();
            listView2 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.BackgroundImage = Properties.Resources.backgrounnds;
            listView1.Location = new Point(-5, -4);
            listView1.Name = "listView1";
            listView1.Size = new Size(576, 421);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.MouseDown += frmGuildRecord_MouseDown;
            listView1.MouseMove += frmGuildRecord_MouseMove;
            listView1.MouseUp += frmGuildRecord_MouseUp;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.gw2eb95q;
            pictureBox2.Location = new Point(498, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(41, 33);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // listView2
            // 
            listView2.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4 });
            listView2.Font = new Font("Gloucester MT Extra Condensed", 18F);
            listView2.Location = new Point(12, 66);
            listView2.Name = "listView2";
            listView2.Size = new Size(439, 316);
            listView2.TabIndex = 15;
            listView2.UseCompatibleStateImageBehavior = false;
            listView2.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Name";
            columnHeader1.Width = 70;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Class";
            columnHeader2.Width = 70;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Position ";
            columnHeader3.Width = 70;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Level";
            columnHeader4.Width = 70;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Gloucester MT Extra Condensed", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 25);
            label1.Name = "label1";
            label1.Size = new Size(195, 38);
            label1.TabIndex = 16;
            label1.Text = "Guild Bar Records : ";
            // 
            // frmGuildRecord
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 404);
            Controls.Add(label1);
            Controls.Add(listView2);
            Controls.Add(pictureBox2);
            Controls.Add(listView1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmGuildRecord";
            Text = "frmGuildRecord";
            Load += frmGuildRecord_Load;
            MouseDown += frmGuildRecord_MouseDown;
            MouseMove += frmGuildRecord_MouseMove;
            MouseUp += frmGuildRecord_MouseUp;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListView listView1;
        private PictureBox pictureBox2;
        private ListView listView2;
        private Label label1;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
    }
}