﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Guild_Registration
{
    public partial class frmGuildRecord : Form
    {
        private bool isDragging = false;
        private Point cursorPoint;
        private Point formPoint;

        public frmGuildRecord()
        {
            InitializeComponent();
            // Subscribe to mouse events
            this.MouseDown += frmGuildRecord_MouseDown;
            this.MouseMove += frmGuildRecord_MouseMove;
            this.MouseUp += frmGuildRecord_MouseUp;
        }

        private void frmGuildRecord_MouseDown(object sender, MouseEventArgs e)
        {
            isDragging = true;
            cursorPoint = Cursor.Position;
            formPoint = this.Location;
        }

        private void frmGuildRecord_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(cursorPoint));
                this.Location = Point.Add(formPoint, new Size(dif));
            }
        }

        private void frmGuildRecord_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmGuildRecord_Load(object sender, EventArgs e)
        {
            // Initialization code if needed
        }
    }
}